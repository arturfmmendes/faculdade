#include <stdio.h>
#include <stdlib.h>

int main(void){

    char caracter[2] = "05";
    int num;

    num = atoi(caracter);

    printf("%d", num);
    return 0;

}