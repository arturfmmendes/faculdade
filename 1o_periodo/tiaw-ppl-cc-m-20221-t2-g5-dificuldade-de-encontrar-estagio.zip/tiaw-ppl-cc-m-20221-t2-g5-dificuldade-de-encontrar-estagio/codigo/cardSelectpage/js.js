
function typeCadastro(type) {
    localStorage.setItem('type', type)
    location.href="../C-Estagiario/index.html"
    console.log(type);
}