localStorage.clear();
function getButton(locate) {
    localStorage.setItem("locate",locate)
}