[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7681645&assignment_repo_type=AssignmentRepo)
# Obstáculos na Busca por estágio
O objetivo geral deste trabalho é a criação de uma aplicação Web que sirva como uma intermediadora na relação empresa-estagiário e vice-versa, trazendo um contato direto e simplificado entre as partes.
Como objetivos específicos, podemos ressaltar:
Comunicação limpa e direta entre as partes envolvidas;
Aplicação simples, de fácil acesso e entendimento;
Painel de divulgação de vagas disponíveis.


## Alunos integrantes da equipe

* Artur Ferreira
* Augusto Noronha
* Daniel Campos
* Felipe Parreiras
* Lucas Vilela
* Marcos Eduardo

## Professores responsáveis

* Carlos Alberto Marques Pietrobom
* Cleiton Silva Tavares
* Daniel de Oliveira Capanema
* Fátima de Lima Procopio Duarte
* Max do Val Machado
* Rommel Viera Carneiro
* Simone de Assis Alves Lima
* Walisson Ferreira de Carvalho

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
